<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_carousel
 *
 * Главный класс контроллера компонента Слайдер Easy Life
 */

defined('_JEXEC') or die;

class CarouselController extends JControllerLegacy {

    // переопределяем вид по умолчанию
    protected $default_view = 'slides';
}
